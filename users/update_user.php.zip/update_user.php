<?php include_once '/includes/header_page.php'; ?>

<?php
    //include_once 'H:\wamp64\www\carwash\includes\dbconn.inc.php';
    // include_once '..\includes\func.inc.php';
    include_once $_SERVER['DOCUMENT_ROOT'].'/carwash/includes/dbconn.inc.php';
    
        if (isset($_GET['id'])) {
            echo "show clicked";
            $sql = "SELECT * FROM users where id=". (int)$_GET['id'];
            $result = mysqli_query($conn,$sql);
            $row_user = mysqli_fetch_assoc($result);
            $user_id =  $row_user['id'];
            $user_email =  $row_user['email'];
            $user_hashpwd = $row_user['hashpwd'];
            echo "
            <div>
            <span>UPDATE USER</span>
            <div>
            <form action=\"includes/update_tournament.inc.php\" method=\"POST\">
                <input type=\"hidden\" name=\"user_id\" value=\"$user_id\" placeholder=\"\"><br />
                <input type=\"text\" name=\"email\" value=\"$user_email\" placeholder=\"Email/Username\"><br />".
                // populateList($tourn_season_id,$tblSeason,$tblSeason)
                "<input type=\"password\" name=\"hashpwd\" value=\"$user_hashpwd\" placeholder=\"Password\"><br />
                <button type=\"submit\" name=\"submit\">Update</button>
            </form>
            </div>
            </div>
            ";
    }   
?>
<?php include '/includes/footer_page.php';?>